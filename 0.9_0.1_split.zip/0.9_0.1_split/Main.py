import os
from keras import backend as K
import tensorflow as tf
import Mul_one_Aim_K1_MLP as MLP
import Mul_one_Aim_K1_CNN as CNN
import Mul_one_Aim_K1_LSTM as LSTM
import Mul_one_Aim_K1_HYBRID as HYBRID
import Mul_one_Aim_K1_SLF as SLF


def clear_funcition():
    K.clear_session()
    tf.reset_default_graph()
    return


Tatol_Epoches = 2*10000
Size_batch = 500


MLP.run_train(Epoches=Tatol_Epoches, Size=Size_batch)
clear_funcition()
CNN.run_train(Epoches=Tatol_Epoches, Size=Size_batch)
clear_funcition()
LSTM.run_train(Epoches=Tatol_Epoches, Size=Size_batch)
clear_funcition()
HYBRID.run_train(Epoches=Tatol_Epoches, Size=Size_batch)
clear_funcition()
SLF.run_train(Epoches=Tatol_Epoches, Size=Size_batch)
clear_funcition()