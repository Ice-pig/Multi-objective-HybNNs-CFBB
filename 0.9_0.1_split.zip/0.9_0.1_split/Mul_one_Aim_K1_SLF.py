import keras
from keras.models import Sequential, Model
from keras.layers import Dense, Dropout, Flatten, concatenate,Activation
from keras.layers import Conv1D, MaxPooling1D
import tensorflow as tf
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.normalization import BatchNormalization
from keras import regularizers
from keras import initializers
from keras.optimizers import Adam, RMSprop, SGD

from keras.layers import LSTM
from keras.layers import Input, Dense, Reshape, Flatten, concatenate
from keras import backend as K
from keras.utils import plot_model
#=============================================

#=============LStm包导入及其他=========
import numpy as np
from tensorflow.contrib import rnn
from sklearn import preprocessing

import time
import datetime
import scipy.io as scio

from sklearn import metrics

from icepig import icepig_dataload
from icepig import test_score_program
from icepig import processing_bar





class Mulaim_Model():

    def __init__(self):

        datasets_filemath = 'F:\\doctor_progress\\Datasets_icepig\\paper_data\\300MW_CFBB_3.mat'

        self.fc_units = 500
        self.time_lable = datetime.datetime.now().strftime('%Y-%m-%d')
        self.min_rmse = 0.2
        self.learning_rate = 1e-4
        self.out_aim = 3

        dataunit = icepig_dataload.Dataload_mul_MinMax(
            datasets_filemath, aim_num = self.out_aim ,   train_size=0.9, test_size=0.1, random_state=911)
        self.x_train, self.y_train, self.x_test, self.y_test = dataunit[0], dataunit[1], dataunit[2], dataunit[3],

        self.input_size = np.shape(self.x_train)[1]
        self.aim_output_dim = self.out_aim


    def build_mul_aim(self):

        input = Input(shape = (self.input_size,))
        x1 = Dense(units=self.fc_units, activation=None, use_bias=True,
                   kernel_initializer=initializers.RandomNormal(mean=0.0, stddev=0.5, seed=None),
                   bias_initializer='zeros',
                   kernel_regularizer=regularizers.l1_l2(0.00), bias_regularizer=None,
                   activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(input)
        x1 = LeakyReLU(alpha=0.2)(x1)
        #x1 = BatchNormalization(momentum=0.8)(x1)


        x1 = Dense(units=self.aim_output_dim, activation=None, use_bias=None,
                   kernel_initializer=initializers.RandomNormal(mean=0.0, stddev=0.5, seed=None),
                   bias_initializer='zeros',
                   kernel_regularizer=regularizers.l1_l2(0.00), bias_regularizer=None,
                   activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(x1)
        #x1 = LeakyReLU(alpha=0.2)(x1)
        #x1 = Activation('sigmoid')(x1)

        model = Model(inputs=input, outputs=x1, name='mul_aim_model')
        model.summary()

        plot_model(model, to_file='.\\SLF\\Mul_model\\mul_aim_model' + str(self.time_lable) + '.png',
                   show_shapes=True, show_layer_names=True, rankdir='LR')

        return model


    def build_model(self):

        input1_ = Input( shape = (self.input_size,) )
        self.sub_mul_model = self.build_mul_aim()
        sub_mul_model_output = self.sub_mul_model(inputs=input1_)
        model = Model(inputs=input1_, outputs=sub_mul_model_output, name='mul_model')
        model.summary()

        return model



    def my_loss(self, y_true, y_pred):

        c = tf.square(y_true - y_pred)
        MSE = tf.reduce_mean(c, axis=0)

        self.k1, self.k2, self.k3, = 1,1,1

        # k1, k2, k3, k4 = 群优化程序
        my_mse = self.k1*MSE[0] + self.k2*MSE[1] + self.k3*MSE[2]

        return (my_mse)


    def train(self, epochs, batch_size):

        x_train, y_train, x_test, y_test = self.x_train, self.y_train, self.x_test, self.y_test


        # Build and compile
        optimizer = Adam(lr=self.learning_rate, beta_1=0.7, beta_2=0.99)

        losses = self.my_loss
        loss_weight = {  "mul_aim_model": 1.0  }

        # "模型名字"："优化算法名"
        #loss_weight = {"NOx_model": 1.0, "SO2_model": 1.0, "Efficiency_model": 1.0}

        self.mul_model = self.build_model()
        self.mul_model.compile(loss=losses, optimizer=optimizer, metrics=['mse'],
                 loss_weights = loss_weight     )



        RMSE_test_unit=[]
        test_data=[]
        loss_unit=[]
        time_data=[]

        MSE_data =[]
        RMSE_data = []
        MAE_data = []
        R2_data = []
        EVS_data = []

        print(self.mul_model.metrics_names)

        time_start = time.clock()
        for i in range(epochs):

            idx_01 = np.random.randint(0, x_train.shape[0], size=batch_size)
            batch_x_train = x_train[idx_01]
            batch_y_train = y_train[idx_01]

            # Train the discriminator
            loss_out = self.mul_model.train_on_batch( x=batch_x_train, y=batch_y_train )
            #loss_out返回的是一个数组，它和metric是一致的，也是loss_out[0]=loss, loss_out[1]=mse
            #=====================test========================================
            y_pre = self.mul_model.predict(x_test)        #预测输出值

            MSE, RMSE, MAE, R2, EVS = test_score_program.mul_score_calculation(y_test, y_pre)

            time_now = time.clock()
            time_consume = time_now - time_start
            timeremain =  (time_consume * (epochs - i) ) / (3600 * (i+0.1) )
            one_epoch_time = timeremain /(i+1)

            time_unit = [i, time_consume, one_epoch_time]
            time_data.append(time_unit)

            MSE_data.append(MSE)
            RMSE_data.append(RMSE)
            MAE_data.append(MAE)
            R2_data.append(R2)
            EVS_data.append(EVS)


            scio.savemat('.\\SLF\\savemat\\SLF-result-data-' + str(self.time_lable) + '.mat',
                         {'time_data': time_data, 'MSE_data': MSE_data, 'RMSE_data': RMSE_data,
                          'MAE_data': MAE_data, 'R2_data': R2_data, 'EVS_data': EVS_data,
                          'y_test': y_test, 'y_pre': y_pre})

            # Plot the progress
            if i % 100 == 0:
                print(i,"  " , R2[0],"  " , R2[1], "  " ,R2[2])
                print("timeremain = %.2f h" % timeremain )

            if RMSE[0] < self.min_rmse:

                self.mul_model.save('.\\SLF\\Mul_model\\Mul-model-' + str(RMSE[0]) + '-' + str(i) + '-' + str(
                    self.time_lable) + '.h5')

                self.min_rmse = RMSE[0] - 0.01

        #=======               =SAVE=                  ===========
        self.mul_model.save('.\\SLF\\Mul_model\\Mul-model-finish' + str(self.time_lable) + '.h5')



def run_train(Epoches=20*1000, Size=500):
    MODEL = Mulaim_Model()
    MODEL.train(epochs=Epoches, batch_size=Size)
    # 使用完模型之后，清空之前model占用的内存
    K.clear_session()
    tf.reset_default_graph()
    return()


if __name__ == '__main__':
    run_train()




